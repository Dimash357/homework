# Task 4
def bill_gates():
    return print(f"“Don't compare yourself with anyone in this world… if you do so, you are insulting yourself.”\nBill Gates")

bill_gates()

# Task 5
def two_numbers(x, y):
    return [i for i in range(x, y+1) if i%2 == 0]

print(two_numbers(1, 7))

# Task 6
def draw_square(n, s, f):
    r = s * n
    if not f:
        m = s + " " * (n - 2) + s
    else:
        m = r
    print(r)
    for i in range(n - 2):
        print(m)
    print(r)
draw_square(7, "^", True)
print()
draw_square(7, "^", False)


# Task 7
def five_numbers(a, b, c, d, f):
    return min(a, b, c, d, f)

print(five_numbers(2, 5, 3, 4, 7))

# Task 8
def multiply(a, b):
    if a == b:
        return "Диапазон слишком маленький"
    if a > b:
        a, b = b, a
    multiple = 1
    for i in range(a, b + 1):
        multiple *= i
    return multiple

print(multiply(1, 7))

# Task 9
def counter(number):
    return len(str(number))

print(counter(4567))

# Task 10
def palindrome(number):
    reversed_number = str(number)
    if reversed_number[::-1].startswith(reversed_number):
        return True
    else:
        return False

print(palindrome(123321))